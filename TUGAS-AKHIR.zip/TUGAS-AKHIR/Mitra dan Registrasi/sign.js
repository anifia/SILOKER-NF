function checkForm(){
    var username = document.querySelector(".Username").value;
    var password = document.querySelector(".Password").value;

    if(username == "" || password == ""){
    alert ("Login Gagal")
    }
    else{
        location.href= "../backend.html"
    }
    
}
